# import xml.etree.ElementTree as ET
# from svgpathtools import parse_path
# import os

# # === Inputs ===
# folder_name = "artworks_18_04_seg_selected"
# filename = "222452fgsdlw"  # Change this as needed
# outfilename = "222452fgsdl"
# input_folder = f"input_svg/{folder_name}/{filename}/vtrace-{outfilename}.svg"
# output_file =  f"input_svg/{folder_name}/{outfilename}/vtrace-{outfilename}_segment_0.svg"

# MAX_PATHS = 3000
# LENGTH_THRESHOLD = 0.0  # Set to 0 to ignore threshold

# # === Parse SVG ===
# tree = ET.parse(input_folder)
# root = tree.getroot()
# namespace = {'svg': 'http://www.w3.org/2000/svg'}
# ET.register_namespace('', namespace['svg'])  # To preserve xmlns in output

# # === Extract path data ===
# path_data = []

# for path_elem in root.findall('.//svg:path', namespace):
#     d_attr = path_elem.attrib.get('d', '')
#     try:
#         length = parse_path(d_attr).length()
#     except Exception:
#         length = 0.0
#     if length > LENGTH_THRESHOLD:
#         path_data.append((path_elem, length))

# # === Sort by path length descending ===
# sorted_paths = sorted(path_data, key=lambda x: x[1], reverse=True)
# top_paths = sorted_paths[:MAX_PATHS]

# # === Create new SVG tree ===
# new_svg = ET.Element('svg', {
#     'xmlns': namespace['svg'],
#     'version': '1.1',
#     'width': root.get('width', '1000'),
#     'height': root.get('height', '1000')
# })

# # Append top paths
# for elem, _ in top_paths:
#     new_svg.append(elem)

# # === Write output ===
# ET.ElementTree(new_svg).write(output_file, encoding='utf-8', xml_declaration=True)
# print(f"✔ Saved sorted SVG with {len(top_paths)} paths to {output_file}")
import xml.etree.ElementTree as ET
from svgpathtools import parse_path

# === Config ===
folder_name = "artworks_18_04_seg_selected"
filename = "van_gogh_portrait_6"          # Input folder/file name
#outfilename = "222452fgsdl"        # Output name without extension

input_file = f"input_svg/{folder_name}/{filename}-w/vtrace-{filename}.svg"
output_folder = f"output_svg/{folder_name}/{filename}"
import os
if not os.path.exists(output_folder):
        os.makedirs(output_folder)
output_file = f"{output_folder}/sequence-vtrace-{filename}_segment_0.svg"

N = 500
namespace = {'svg': 'http://www.w3.org/2000/svg'}
ET.register_namespace('', namespace['svg'])

# === Parse SVG ===
tree = ET.parse(input_file)
root = tree.getroot()

# === Extract and compute path lengths ===
paths = root.findall('.//svg:path', namespace)
path_data = []
for path in paths:
    d = path.attrib.get('d', '')
    try:
        length = parse_path(d).length()
        path_data.append((path, length))
    except Exception:
        continue

# === Sort and take top N ===
sorted_paths = sorted(path_data, key=lambda x: x[1], reverse=True)
top_paths = sorted_paths[:N]

# === Create new SVG root ===
new_svg = ET.Element('svg', {
    #'xmlns': namespace['svg'],
    'version': '1.1',
    'width': root.get('width', '1000'),
    'height': root.get('height', '1000')
})

# === Add top N paths ===
for path_elem, _ in top_paths:
    new_svg.append(path_elem)

# === Save to file ===
ET.ElementTree(new_svg).write(output_file, encoding='utf-8', xml_declaration=True)
print(f"✅ Saved top {len(top_paths)} paths to {output_file}")
