from gradio_client import Client

client = Client("https://carolineec-informativedrawings.hf.space/")
result = client.predict(
				"https://raw.githubusercontent.com/gradio-app/gradio/main/test/test_files/bus.png",	# str (filepath or URL to image)in 'input_img' Image component
				"style 1",	# str in 'version' Radio component
				api_name="/predict"
)
print(result)