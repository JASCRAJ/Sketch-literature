import os
import xml.etree.ElementTree as ET
from svgpathtools import parse_path

# === Configuration ===
filename = "alma"
folder_name = "artworks_18_04_seg_selected"
N = 500  # Number of top paths to keep

input_file = f"input_svg/{folder_name}/{filename}-w/vtrace-{filename}.svg"
output_folder = f"output_svg/{folder_name}/{filename}"
output_file = f"{output_folder}/sequence-vtrace-{filename}_segment_0.svg"

# Create output directory if not exists
os.makedirs(output_folder, exist_ok=True)

# === SVG Namespace ===
namespace = {'svg': 'http://www.w3.org/2000/svg'}
ET.register_namespace('', namespace['svg'])

# === Parse SVG File ===
tree = ET.parse(input_file)
root = tree.getroot()

# === Extract Path Elements in Order ===
paths = root.findall('.//svg:path', namespace)
top_paths = paths[:N]  # Just take the first N paths as-is

# === Create New SVG Root ===
new_svg = ET.Element('svg', {
    'version': '1.1',
    'width': root.get('width', '1000'),
    'height': root.get('height', '1000'),
    #'xmlns': namespace['svg']
})

# === Add Selected Paths ===
for path_elem in top_paths:
    new_svg.append(path_elem)

# === Write Output File ===
ET.ElementTree(new_svg).write(output_file, encoding='utf-8', xml_declaration=True)
print(f"✅ Saved {len(top_paths)} paths (in order) to: {output_file}")
