import cv2
import os

# Set the path to your MP4 file and the folder to save frames
video_path = 'results/ffhq/13-combined-sequence-brush_7-combined-output-video-polygonandcropimageR1.mp4'  # Replace with your video path
output_folder = 'frames/ffhq/13/'  # Folder where frames will be saved

# Create output folder if it doesn't exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Open the video file
cap = cv2.VideoCapture(video_path)

# Get the total number of frames in the video
frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

# Loop through all frames and save them as images
for frame_num in range(frame_count):
    ret, frame = cap.read()
    if ret:
        # Save the frame as an image
        frame_filename = os.path.join(output_folder, f'frame_{frame_num:04d}.jpg')
        cv2.imwrite(frame_filename, frame)

# Release the video capture object
cap.release()

print(f"Frames extracted to {output_folder}")
