import os

# Define paths
base_folder = "output_svg/artwork_jpg_selected"
sketches_bw_folder = os.path.join(base_folder, "sketches_bw")
imgs_folder = os.path.join(base_folder, "imgs")
combined_folder = os.path.join(base_folder, "combined_svgs")

# Ensure the output directory exists
os.makedirs(combined_folder, exist_ok=True)

# Process each SVG in sketches_bw
for file in os.listdir(sketches_bw_folder):
    if file.endswith(".svg"):  # Only process SVG files
        file_name = os.path.splitext(file)[0]  # Get filename without extension

        # Paths for sketches_bw SVG and imgs SVG
        sketch_svg_path = os.path.join(sketches_bw_folder, file)
        img_svg_path = os.path.join(imgs_folder, file)

        # Check if corresponding SVG exists in imgs folder
        if not os.path.exists(img_svg_path):
            print(f"Skipping {file_name}: No matching SVG in 'imgs' folder.")
            continue

        # Read SVG content from both files
        with open(sketch_svg_path, "r", encoding="utf-8") as f:
            sketch_svg_content = f.readlines()  # Read as a list of lines

        with open(img_svg_path, "r", encoding="utf-8") as f:
            img_svg_content = f.readlines()

        # Remove SVG headers and footers to avoid duplication
        sketch_svg_body = sketch_svg_content[1:-1]  # Remove first and last lines
        img_svg_body = img_svg_content[1:-1]  # Remove first and last lines

        # Construct the merged SVG
        merged_svg = (
            sketch_svg_content[0] +  # Start with the original <svg> tag
            "".join(sketch_svg_body) +  # Append sketch SVG content
            "".join(img_svg_body) +  # Append image SVG content
            sketch_svg_content[-1]  # End with the closing </svg> tag
        )

        # Save the combined SVG
        combined_svg_path = os.path.join(combined_folder, file)
        with open(combined_svg_path, "w", encoding="utf-8") as f:
            f.write(merged_svg)

        print(f"Combined SVG saved: {combined_svg_path}")
