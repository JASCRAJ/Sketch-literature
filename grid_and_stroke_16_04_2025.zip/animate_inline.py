import os
import argparse

# Set up argument parser
parser = argparse.ArgumentParser(description='Combine HTML and SVG files.')
parser.add_argument('svg_results_folder', type=str, help='Path to the folder containing SVG files')
args = parser.parse_args()

# Inline content for head.html and script.html
head_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG Path Animation</title>
  <style>
    /* CSS styles for SVG paths */
    .path {
      stroke-width: 0.5;
      stroke: none;
      stroke-dasharray: 1000; /* Adjust based on path length */
      stroke-dashoffset: 1000; /* Adjust based on path length */
      fill-opacity: 0; /* Initially hide fill */
    }
  </style>
</head>
<body>
"""

script_content = """  <script>
    // Wait for the DOM content to be loaded
    document.addEventListener("DOMContentLoaded", function() {
      // Select all paths within the SVG
      const paths = document.querySelectorAll('svg path');
	// Add class "path" to each path
    paths.forEach(path => {
      path.classList.add('path');
    });
      // Loop through each path and animate
      paths.forEach((path, index) => {
	const length = path.getTotalLength();
      
      // Set initial styles
      path.style.strokeDasharray = length;
      path.style.strokeDashoffset = length;
      

        setTimeout(() => {
          path.style.strokeDashoffset = 0;
          path.style.fillOpacity = 1; // Show fill
          path.style.transition = 'stroke-dashoffset 0.1s ease-in-out';
	  path.style.strokeDashoffset = '0';
        }, index * 10); // Adjust timing (decreased from 1000 to 500 for faster animation)
      });
    });
  </script>

</body>
</html>
"""

# Define the names of the files to be combined
animatefile_prefix = 'animate_'  # Prefix for output files
output_directory = 'output_animations/sketchpaint_comp/'  # Directory to save combined files

# Create the output directory if it doesn't exist
os.makedirs(output_directory, exist_ok=True)

# Get a list of all SVG files in the results folder specified in the terminal
svg_files = [f for f in os.listdir(args.svg_results_folder) if f.endswith('.svg')]

# Combine each SVG file with the inline content
for svg_file_name in svg_files:
    # Define the combined file name for the current SVG file
    animatefile_name = f"{animatefile_prefix}{svg_file_name.replace('.svg', '.html')}"
    
    # Define the full path for the combined file in the output directory
    full_animatefile_path = os.path.join(output_directory, animatefile_name)

    # Open the combined file in write mode
    with open(full_animatefile_path, 'w') as animatefile:
        # Write inline head content to combined file
        animatefile.write(head_content)

        # Open and read the SVG file
        with open(os.path.join(args.svg_results_folder, svg_file_name), 'r') as svg_file:
            svg_content = svg_file.read()
            animatefile.write(svg_content + '\n')  # Write SVG file content to combined file

        # Write inline script content to combined file
        animatefile.write(script_content)

    print(f"{full_animatefile_path} created successfully.")
