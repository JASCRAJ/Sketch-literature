import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPolygon
from shapely.geometry import Polygon, LineString
from shapely.ops import split
from svgpath2mpl import parse_path
from matplotlib.path import Path
import numpy as np
import math
from shapely.ops import nearest_points
from PIL import Image, ImageDraw, ImageChops

# Define your SVG path data
svg_path_data = "M 892.5,843.5 C 893.846,845.792 893.512,847.792 891.5,849.5C 886.947,849.843 883.947,851.676 882.5,855C 883.43,857.138 885.097,858.305 887.5,858.5C 883.763,861.527 879.43,863.193 874.5,863.5C 871.123,863.959 867.789,864.626 864.5,865.5C 858.62,865.048 852.953,865.882 847.5,868C 845.576,869.75 843.909,871.583 842.5,873.5C 840.486,873.392 838.82,874.058 837.5,875.5C 835.952,875.821 835.285,876.821 835.5,878.5C 834.167,878.5 832.833,878.5 831.5,878.5C 831.5,879.5 831.5,880.5 831.5,881.5C 830.486,882.674 829.153,883.34 827.5,883.5C 824.15,883.335 820.817,883.502 817.5,884C 814.808,884.743 812.475,885.91 810.5,887.5C 808.833,887.5 807.167,887.5 805.5,887.5C 803.738,887.357 802.071,887.691 800.5,888.5C 799.478,888.145 798.811,887.478 798.5,886.5C 818.533,879.158 838.199,870.658 857.5,861C 870.309,857.262 881.976,851.429 892.5,843.5 Z"
#"M0,0 L3,0 L1,13 L6,13 L6,11 L10,11 L10,14 L16,13 L18,14 L20,10 L23,10 L23,12 L21,12 L21,14 L24,12 L26,8 L27,8 L27,15 L22,24 L21,28 L25,29 L25,31 L21,31 L21,34 L16,35 L18,42 L16,46 L14,47 L14,52 L12,54 L9,54 L9,57 L3,59 L1,58 L1,55 L6,56 L5,53 L8,53 L8,49 L10,46 L13,46 L13,44 L11,44 L11,39 L15,39 L14,36 L9,38 L9,36 L14,31 L15,25 L11,25 L11,28 L8,29 L8,27 L3,29 L2,22 L8,19 L9,15 L0,16 L0,13 L-2,12 L0,12 L-2,9 Z " 

# Convert SVG path to matplotlib path
mpl_path = parse_path(svg_path_data)

polygon_vertices = mpl_path.to_polygons()[0]  # Extract vertices from path
#img.show()

# Flip the y-coordinates to match SVG's coordinate direction
#polygon_vertices[:, 1] = -polygon_vertices[:, 1]

# Create a Shapely polygon from the adjusted vertices
shapely_polygon = Polygon(polygon_vertices)
print(shapely_polygon.envelope)
print(shapely_polygon.envelope.area)
print(shapely_polygon.bounds)
centroid = shapely_polygon.centroid
print(centroid)
minx, miny, maxx, maxy = shapely_polygon.bounds
#print(polygon.bounds)
bounding_box = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
print(minx, miny, maxx, maxy)
width = maxx - minx
height = maxy - miny
print(width, height)
adjusted_bounding_box = [(x - minx, y - miny) for x, y in bounding_box]
img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
draw = ImageDraw.Draw(img)
draw.polygon(adjusted_bounding_box, outline=None, fill="red")
#img.show()
current_frame = Image.open('input\jpraj.png')
canvas_width = 1500
paste_x = min(max(minx, 0), 1500 - width)
paste_y = min(max(miny, 0), 1500 - height)
print(f"paste, {paste_x, paste_y}")
#current_frame.paste(img, (paste_x, paste_y), img)
#polygon = Polygon(coords)

# Check if the polygon's orientation is counterclockwise (CCW)
# is_counterclockwise = shapely_polygon.is_ccw
# print(is_counterclockwise)
from sklearn.decomposition import PCA
coords = list(shapely_polygon.exterior.coords)
pca = PCA(n_components=1)
pca.fit(coords)

# Get the angle of the principal component
angle = np.arctan2(pca.components_[0, 1], pca.components_[0, 0])
angle_degrees = np.degrees(angle)
print(f"Principal component direction: {angle_degrees} degrees")


# Compute the signed area (shoelace formula)
# area = 0
# for i in range(len(coords) - 1):
#     x1, y1 = coords[i]
#     x2, y2 = coords[i + 1]
#     area += x1 * y2 - x2 * y1
# area = area / 2

# # Check if the polygon is clockwise or counterclockwise
# if area > 0:
#     delta_x = maxx - minx
#     delta_y = miny - maxy
# else:
#     delta_x = maxx - minx
#     delta_y = maxy - miny
# #current_frame.show()

# angle_deg = np.degrees(np.arctan2(delta_y, delta_x))
# # angle_radians = math.atan2(delta_y, delta_x)  # atan2 handles all quadrants
# # angle_deg = 90+math.degrees(angle_radians)  # Convert to degrees
# print(angle_deg)
#print(jp)
img.show()
#current_frame.paste(img, (paste_x, paste_y), img)
#current_frame.show()
#current_frame.save("patch.png")
img = img.rotate(angle_degrees, expand=True)
#img.show()
current_frame.paste(img, (paste_x, paste_y), img)
current_frame.save("patch1.png")
#img = img.rotate(45)
#current_frame.paste(img, (paste_x+100, paste_y+100), img)
current_frame.show()
#print(jp)
# Find the centroid of the polygon
centroid = shapely_polygon.centroid
print(centroid)
# Find the nearest point on the polygon boundary from the centroid
nearest_point = nearest_points(centroid, shapely_polygon.boundary)[1]
print(nearest_point.x)

# Access all coordinates (including exterior and interior)
coordinates = list(shapely_polygon.exterior.coords)

# To account for any possible interior rings (holes), add them as well
for interior in shapely_polygon.interiors:
    coordinates.extend(list(interior.coords))

# Find the smallest and farthest y-values
min_y = min(coord[1] for coord in coordinates)  # smallest y
max_y = max(coord[1] for coord in coordinates)  # farthest y
min_x = min(coord[0] for coord in coordinates)  # smallest y
max_x = max(coord[0] for coord in coordinates)  # farthest y
print("Smallest y-value:", min_y)
print("Farthest y-value:", max_y)
print("Smallest y-value:", min_x)
print("Farthest y-value:", max_x)
print(jp)
center_line = LineString([(nearest_point.x, min_y), (nearest_point.x, max_y)]) 
print(center_line)
# Split the Shapely polygon
split_polygons = split(shapely_polygon, center_line)

# Check if the split occurs
if split_polygons.is_empty:
    print("No split occurred. Ensure the splitting line intersects the polygon.")
else:
    # Plot the original polygon and the split polygons
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))

    # Plot the original polygon
    axes[0].add_patch(MplPolygon(polygon_vertices, closed=True, edgecolor='black', facecolor='lightgray'))
    #axes[0].axhline(y=split_point[1], color='red', linestyle='--', label='Splitting Line')
    axes[0].set_xlim(min(polygon_vertices[:, 0]) - 10, max(polygon_vertices[:, 0]) + 10)
    axes[0].set_ylim(min(polygon_vertices[:, 1]) - 10, max(polygon_vertices[:, 1]) + 10)
    axes[0].set_aspect('equal')
    axes[0].set_title("Original Polygon")
    axes[0].legend()

    # Plot the split polygons
    for i, part in enumerate(split_polygons.geoms):  # Use `geoms` to iterate GeometryCollection
        print(f"Polygon {i}: {part.wkt}")  # Print WKT of the split polygon for debugging
        part_patch = MplPolygon(np.array(part.exterior.coords), closed=True, edgecolor='black', facecolor=np.random.rand(3,))
        axes[1].add_patch(part_patch)

    axes[1].set_xlim(min(polygon_vertices[:, 0]) - 10, max(polygon_vertices[:, 0]) + 10)
    axes[1].set_ylim(min(polygon_vertices[:, 1]) - 10, max(polygon_vertices[:, 1]) + 10)
    axes[1].set_aspect('equal')
    axes[1].set_title("Split Polygons")

    plt.tight_layout()
    plt.show()
