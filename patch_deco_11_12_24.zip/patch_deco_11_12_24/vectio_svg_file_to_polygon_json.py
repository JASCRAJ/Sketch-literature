import xml.etree.ElementTree as ET
from svgpath2mpl import parse_path
from shapely.geometry import Polygon
import json
import re
import numpy as np

# Input SVG file
filename = "NOpavan"
input_svg_file = f"output_svg/{filename}-combined-sequence.svg"#pavan-combined-sequence.svg"
output_file = f"json/{filename}-combined-sequence-with_attributes.json"
def extract_fill_colour(style):
    print(style)
    print(jp)
    match = re.search(r'fill:\s*([^;]+)', style)
    if match:
        return match.group(1)
    return None  # Return None if no fill color is found
# Parse the SVG file and extract path data along with attributes
def extract_svg_paths_with_attributes(svg_file):
    tree = ET.parse(svg_file)
    root = tree.getroot()
    namespace = {'svg': 'http://www.w3.org/2000/svg'}
    path_data = []
    viewbox = root.attrib.get("viewBox")
    # width = 1500
    # height = 1500

    if viewbox:
        min_x, min_y, width, height = map(int, viewbox.split())
    else:
        width = float(root.attrib.get("width", 1500))  # Fallback to default width
        height = float(root.attrib.get("height", 1500))  # Fallback to default height

    for path in root.findall('.//svg:path', namespace):
        svg_path_data = path.get('d')
        transform = path.get('transform')
        style = path.get('style')
        fill_colour = path.get('fill')
        #print(fill_colour)
        if svg_path_data:
            # fill_colour = None
            # if style:
            #     fill_colour = extract_fill_colour(style)
            path_data.append({
                'path': svg_path_data,
                'transform': transform,
                'style': style,
                'fill_colour': fill_colour,
                'width': width,
                'height': height
            })
    return path_data

# Extract paths and attributes
svg_data = extract_svg_paths_with_attributes(input_svg_file)
print(len(svg_data))
def apply_transform(poly, transform):
    if transform and "translate" in transform:
        # Extract translation values
        match = re.search(r"translate\(([^,]+),([^\)]+)\)", transform)
        if match:
            tx, ty = map(float, match.groups())
            poly[:, 0] += tx  # Apply x translation
            poly[:, 1] += ty  # Apply y translation
    # Extend this function if other transformations like scaling or rotation are needed
    return poly

# Process paths and save WKT along with transformations
output_data = []
x = 0
for data in svg_data:
    svg_path_data = data['path']
    transform = data['transform']
    style = data['style']
    fill_colour = data['fill_colour']
    width = data['width']
    height = data['height']
    #print(svg_path_data)
    mpl_path = parse_path(svg_path_data)
    polygons = mpl_path.to_polygons()
    #x = x+ len(polygons)
    # x+=le
    # if(len(polygons)> 1):
    #     print(len(polygons))
    #print(f"Number of polygons: {len(polygons)}")
    #print(polygons)
    #print(transform)
    #print(jp)
    #print(fill_colour)
    #x+=1
    #if (x == 10):
      #  break
    #print(jp)
    for poly in polygons:
        # Ensure poly is a numpy array for easy manipulation
        poly = np.array(poly)

        #print(poly)
        
        # Flip y-coordinates to match SVG's coordinate system
        #poly[:, 1] = -poly[:, 1]
        
        #print(f"Number of polygons: {len(poly)}")
        # Apply transformation
        #poly = apply_transform(poly, transform)
        
        #print(poly)
        # Convert to Shapely polygon
        shapely_polygon = Polygon(poly)
        #print(shapely_polygon)
        #print(Jp)
        #print(f"Saving fill colour: {fill_colour}")
        # Save polygon WKT along with attributes, width and height
        output_data.append({
            'wkt_string': shapely_polygon.wkt,
            'transform': transform,
            'style': style,
            'fill_colour':fill_colour,
            'canvas_width': width,
            'canvas_height': height
        })

# Save output as JSON
with open(output_file, "w") as json_file:
    json.dump(output_data, json_file, indent=4)

print(len(output_data))
print(f"Data saved to {output_file}")
# print("Final output data:")
# for item in output_data:
#     print(item)
#print(x)