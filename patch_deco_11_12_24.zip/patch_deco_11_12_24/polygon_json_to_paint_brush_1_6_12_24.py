import json
import cv2
from shapely.geometry import Polygon
from PIL import Image, ImageDraw, ImageChops
from shapely import wkt, Point
import numpy as np

# Input/Output file configuration
file_name = "pavan"
brush_name = "brush_2_1"
INPUT_JSON_FILE = f"json/{file_name}-combined-sequence-with_attributes.json"  # Input JSON file
OUTPUT_VIDEO_NAME = f"results/{file_name}-combined-sequence-{brush_name}-output-video-cropimage.mp4"  # Output video file
LAST_FRAME_OUTPUT = f"results/{file_name}-combined-sequence-{brush_name}-last_frame-cropimage.png"  # Last frame output
INPUT_CANVAS_IMAGE = f"sketch/{file_name}.png"  # Input canvas image
input_image = f"input/{file_name}.jpg"
BRUSH_IMAGE = f"brushes/{brush_name}.png"  # Brush stroke image


# Function to process each row in the JSON and update the current frame
def process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
    polygon = wkt.loads(wkt_string)
    minx, miny, maxx, maxy = polygon.bounds
    bounding_box = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
    minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    
    point1, point2 = Point(minx, miny), Point(maxx, maxy)
    #angle_deg = 0
    angle_deg = np.degrees(np.arctan2(point2.y - point1.y, point2.x - point1.x))
    width = maxx - minx
    height = maxy - miny

    if width < 1 or height < 1:
        print("Width and height must be >= 1. Skipping resize operation.")
        return current_frame
    
    bounding_box_i = (round(minx), round(miny), round(maxx), round(maxy))
    # Open the image and crop
    image = Image.open(input_image).convert('RGBA')
    cropped_image = image.crop(bounding_box_i)
    #cropped_image.show()
    #print(JP)
    # adjusted_bounding_box = [(x - minx, y - miny) for x, y in bounding_box]
    # img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    # draw = ImageDraw.Draw(img)
    # draw.polygon(adjusted_bounding_box, outline=None, fill=fill_colour)

    try:
        brush_stroke = Image.open(BRUSH_IMAGE)
    except Exception as e:
        print(f"Error loading brush stroke image: {e}")
        return current_frame

    # img = img.resize((width-2, height-2))
    # resized_image_brush = brush_stroke.resize((width-2, height-2))
    #alpha = 0.9  # Transparency level
    #cropped_image =  Image.blend(img, cropped_image, alpha=0.2)
    #cropped_image.show()

    # Combine image1 and the semi-transparent image2
    #bbox_crop_in = Image.alpha_composite(img, cropped_image)
    #img.show()
    #ropped_image.show()
    #bbox_crop_in.show()
    #print(Jp)
    #bbox_crop_in = Image.alpha_composite(img, cropped_image)

    resized_image_brush = brush_stroke.resize((width, height))
    if resized_image_brush.mode != 'RGBA':
        resized_image_brush = resized_image_brush.convert('RGBA')

    base_r, base_g, base_b, base_a = cropped_image.split()#img.split()
    overlay_r, overlay_g, overlay_b, overlay_a = resized_image_brush.split()
    result_r = Image.composite(ImageChops.multiply(base_r, overlay_r), base_r, overlay_a)
    result_g = Image.composite(ImageChops.multiply(base_g, overlay_g), base_g, overlay_a)
    result_b = Image.composite(ImageChops.multiply(base_b, overlay_b), base_b, overlay_a)

    result_image = Image.merge("RGBA", (result_r, result_g, result_b, overlay_a))
    #result_image = result_image.rotate(angle_deg, resample=Image.BICUBIC, expand=True)
    
    paste_x = min(max(minx, 0), canvas_width - width)
    paste_y = min(max(miny, 0), canvas_height - height)
    current_frame.paste(result_image, (paste_x, paste_y), result_image)
    return current_frame

# Main execution
with open(INPUT_JSON_FILE, 'r') as file:
    data_1 = json.load(file)

first_entry = data_1[0]
canvas_width = int(first_entry["canvas_width"])
canvas_height = int(first_entry["canvas_height"])

video_writer = cv2.VideoWriter(OUTPUT_VIDEO_NAME, cv2.VideoWriter_fourcc(*'XVID'), 120, (canvas_width, canvas_height))
try:
    current_frame = Image.open(INPUT_CANVAS_IMAGE).convert('RGBA')
except FileNotFoundError:
    print(f"Sketch not found: {INPUT_CANVAS_IMAGE}")
    current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(255, 255, 255, 255))
# current_frame = Image.open(INPUT_CANVAS_IMAGE).convert('RGBA')
#current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(255, 255, 255, 255))

for idx, row in enumerate(data_1):
    wkt_string = row.get('wkt_string')
    fill_colour = row.get('fill_colour', "red")
    current_frame = process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

    frame = np.array(current_frame)
    frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
    if idx == len(data_1) - 1:
        current_frame.save(LAST_FRAME_OUTPUT)
        print(f"Image created and saved as {LAST_FRAME_OUTPUT}")

    video_writer.write(frame)
    print(f"Processed frame {idx + 1}")

video_writer.release()
print(f"Video created and saved as {OUTPUT_VIDEO_NAME}")
