import json
import cv2
from shapely.geometry import Polygon
from PIL import Image, ImageDraw, ImageChops
from shapely import wkt, Point
import numpy as np
from sklearn.decomposition import PCA

file_name = "NOpavan"
brush_name = "brush_7"
INPUT_JSON_FILE = f"json/{file_name}-combined-sequence-with_attributes.json"  # Input JSON file
OUTPUT_VIDEO_NAME = f"results/{file_name}-combined-sequence-{brush_name}-output-video-polygonandcropimage.mp4"  # Output video file
LAST_FRAME_OUTPUT = f"results/{file_name}-combined-sequence-{brush_name}-last_frame-polygonandcropimage.png"  # Last frame output
INPUT_CANVAS_IMAGE = f"sketch/{file_name}.png"  # Input canvas image
#input_image = f"input/{file_name}.jpg"
BRUSH_IMAGE = f"brushes/{brush_name}.png"  # Brush stroke image

#input_image_for_crop = Image.open(input_image).convert('RGBA')
brush_stroke = Image.open(BRUSH_IMAGE)

# Function to process each row in the JSON and update the current frame
def process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
    # Parse the WKT string into a Shapely Polygon
    # polygon = wkt.loads(wkt_string)
    # minx, miny, maxx, maxy = polygon.bounds
    # minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    
    # # Create a blank image with a transparent background (RGBA mode) for the polygon
    # width = maxx - minx
    # height = maxy - miny
    # img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
    # draw = ImageDraw.Draw(img)

    # # Adjust the coordinates of the polygon to align with the image's (0, 0) origin
    # adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]
    
    # # Draw the polygon on the image
    # draw.polygon(adjusted_coords, outline=None, fill=fill_colour)
    polygon = wkt.loads(wkt_string)
    #print(polygon[0])
    centroid = polygon.centroid
    #print(f"Centroid: {centroid.x}, {centroid.y}")
    minx, miny, maxx, maxy = polygon.bounds
    bounding_box = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
    minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    #print(minx, miny, maxx, maxy)
    point1, point2 = Point(minx, miny), Point(centroid.x, centroid.y)
    angle_deg = np.degrees(np.arctan2(point2.y - point1.y, point2.x - point1.x))/2
    #print(f"The orientation angle of the object relative to the x-axis is: {angle_deg} degrees")
    #print(point1, point2, angle_deg)
    print(angle_deg)
    #print(polygon.bounds)
    #print(jp)
    # Create a blank image with a transparent background (RGBA mode)
    width = maxx - minx
    height = maxy - miny
    if width < 1 or height < 1:
        print("Width and height must be >= 2. Skipping resize operation.")
        return current_frame
    #print(width, height)
    # Adjust the coordinates of the polygon to align with the image's (0, 0) origin
    #adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]
    adjusted_bounding_box = [(x - minx, y - miny) for x, y in bounding_box]
    # Draw the polygon on the image
    #draw.polygon(adjusted_coords, outline=None, fill=fill_colour)
    # print(bounding_box)
    # print(adjusted_bounding_box)
    # scaled_bounding_box = [
    #     (
    #         (x / width) * canvas_width,  # Scale x
    #         (y / height) * canvas_height  # Scale y
    #     )
    #     for x, y in adjusted_bounding_box
    #     ]
    # print(scaled_bounding_box)
    # #draw.polygon(adjusted_bounding_box, outline="red", fill=fill_colour)

    # min_x = min(scaled_bounding_box, key=lambda coord: coord[0])[0]
    # max_x = max(scaled_bounding_box, key=lambda coord: coord[0])[0]
    # min_y = min(scaled_bounding_box, key=lambda coord: coord[1])[1]
    # max_y = max(scaled_bounding_box, key=lambda coord: coord[1])[1]

    # Calculate the width and height of the scaled polygon
    # scaled_polygon_width = max_x - min_x
    # scaled_polygon_height = max_y - min_y

    # # Print the width and height
    # print(f"Scaled Polygon Width: {scaled_polygon_width}")
    # print(f"Scaled Polygon Height: {scaled_polygon_height}")
    #print(jp)
    img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
    draw = ImageDraw.Draw(img)
    draw.polygon(adjusted_bounding_box, outline=None, fill=fill_colour)
    #img.show()
    #print(jp)
    # Load the brush stroke image
    # Load the brush stroke image
    # try:
    #     brush_stroke = Image.open("brushes/brush_1.png")
    # except Exception as e:
    #     print(f"Error loading brush stroke image: {e}")
    #     return current_frame

    # Resize the brush stroke to fit the cropped region size
    #resized_image_brush = brush_stroke.resize((width, height))
    resized_image_brush = brush_stroke.resize((width, height)).convert('RGBA')
    #print(img.size)
    #print(resized_image_brush.size)
    #resized_image_brush.show()
    #print(jp)
    # Ensure the brush stroke image is in RGBA mode
    # if resized_image_brush.mode != 'RGBA':
    #     resized_image_brush = resized_image_brush.convert('RGBA')

    # Split into individual bands for blending
    base_r, base_g, base_b, base_a = img.split()
    overlay_r, overlay_g, overlay_b, overlay_a = resized_image_brush.split()

    # Multiply the RGB channels of base and overlay
    result_r = Image.composite(ImageChops.multiply(base_r, overlay_r), base_r, overlay_a)
    result_g = Image.composite(ImageChops.multiply(base_g, overlay_g), base_g, overlay_a)
    result_b = Image.composite(ImageChops.multiply(base_b, overlay_b), base_b, overlay_a)

    # Combine the result and use the overlay's alpha channel
    result_image = Image.merge("RGBA", (result_r, result_g, result_b, overlay_a))
    angle_deg=10
    result_image = result_image.rotate(angle_deg, expand=True)
    #result_image.show()
    #print(Jp)
    # Paste the composite image onto the current frame
    #coords = polygon.exterior.coords   

    # Get the first two vertices (coordinates)
    #vertex_1 = (int(coords[0][0]), int(coords[0][1]))  # First vertex
    #vertex_2 = coords[1]  # Second vertex

    #print("First vertex:", vertex_1)
    #print("Second vertex:", vertex_2)
    paste_x = min(max(minx, 0), canvas_width - width)
    paste_y = min(max(miny, 0), canvas_height - height)
    #print(paste_x, paste_y)
    #print(fill_colour)
    current_frame.paste(result_image, (paste_x, paste_y), result_image)  # Use result_image as a mask
    #current_frame.show()
    #print(jp)
    return current_frame

# Load the JSON data
# input_json_file = "json/pavan-combined-sequence-with_attributes.json"
# output_video_name = 'results/pavan-combined-sequence-brush_1-output-video.mp4'

# OpenCV VideoWriter setup
fps = 30  # Frames per second
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Codec for .avi format
with open(INPUT_JSON_FILE, 'r') as file:
    data_1 = json.load(file)

first_entry = data_1[0]
canvas_width = int(first_entry["canvas_width"])
canvas_height = int(first_entry["canvas_height"])

video_writer = cv2.VideoWriter(OUTPUT_VIDEO_NAME, cv2.VideoWriter_fourcc(*'XVID'), 120, (canvas_width, canvas_height))
try:
    current_frame = Image.open(INPUT_CANVAS_IMAGE).convert('RGBA')
except FileNotFoundError:
    print(f"Sketch not found: {INPUT_CANVAS_IMAGE}")
    current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(255, 255, 255, 255))

# with open(input_json_file, 'r') as file:
#     data_1 = json.load(file)  # Load the JSON data from the file

# Access the desired data
# print(len(data_1))
# first_entry = data_1[0]  # Get the first dictionary

# # Extract the desired data
# canvas_width = int(first_entry["canvas_width"])
# canvas_height = int(first_entry["canvas_height"])
print(canvas_width, canvas_height)
for idx, row in enumerate(data_1):
    wkt_string = row.get('wkt_string')
    fill_colour = row.get('fill_colour', "red")
    current_frame = process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

    frame = np.array(current_frame)
    # if frame.shape[-1] != 4: 
    #     pil_image = Image.fromarray(frame)

    #     # Now you can use show() to display the image
    #     pil_image.show()
    #     #frame.show()
    frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
    
    if idx == len(data_1) - 1:
        current_frame.save(LAST_FRAME_OUTPUT)
        print(f"Image created and saved as {LAST_FRAME_OUTPUT}")

    video_writer.write(frame)
    print(f"Processed frame {idx + 1}")

video_writer.release()
print(f"Video created and saved as {OUTPUT_VIDEO_NAME}")

# canvas_width = data_1['canvas_width'][0]
# canvas_height = data_1["canvas_height"][0]
#canvas_width = 1270  # Default canvas width
#canvas_height = 1240  # Default canvas height

# Create a VideoWriter object to write frames to the video file
#video_writer = cv2.VideoWriter(output_video_name, fourcc, fps, (canvas_width, canvas_height))

# Initialize the current frame with a blank canvas

#current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(255, 255, 255, 255))
# file_name = "pavan"
# INPUT_CANVAS_IMAGE = f"sketch/{file_name}.png"
# try:
#     current_frame = Image.open(INPUT_CANVAS_IMAGE).convert('RGBA')
# except FileNotFoundError:
#     print(f"Sketch not found: {INPUT_CANVAS_IMAGE}")
#     current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(255, 255, 255, 255))
# Process each entry in the JSON file and accumulate frames
# with open(input_json_file, "r") as json_file:
#     print(json_file)
#     data = json.load(json_file)
#     l_data = len(data)
#     print(l_data)
#     #print(jp)
#     for idx, row in enumerate(data):
#         wkt_string = row.get('wkt_string')
#         fill_colour = row.get('fill_colour', "red")  # Default to red if not provided
#         #canvas_width = row.get('canvas_width')
#         #print(canvas_width)
#         #print(jp)
#         #print(idx)
#         #canvas_height = row.get('canvas_height')
#         # Update the current frame with the new polygon data
#         current_frame = process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

#         # Convert the current frame to a format suitable for OpenCV (BGR)
#         frame = np.array(current_frame)
#         frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
#         if idx == l_data-1:
#             current_frame.save("results/pavan-combined-sequence-brush_1-last_frame.png")
#             print(f"image created and saved")
#         # if idx == 10:
#         #     break;
#         # Write the frame to the videoWWW
#         video_writer.write(frame)

#         print(f"Processed frame {idx + 1}")

# # Release the video writer and finalize the video file
# video_writer.release()
# print(f"Video created and saved as {output_video_name}")
