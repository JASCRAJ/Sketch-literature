import json
import cv2
from shapely.geometry import Polygon
from PIL import Image, ImageDraw, ImageChops
from shapely import wkt
import numpy as np

# Function to process each row in the JSON and update the current frame
def process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
    # Parse the WKT string into a Shapely Polygon
    # polygon = wkt.loads(wkt_string)
    # minx, miny, maxx, maxy = polygon.bounds
    # minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    
    # # Create a blank image with a transparent background (RGBA mode) for the polygon
    # width = maxx - minx
    # height = maxy - miny
    # img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
    # draw = ImageDraw.Draw(img)

    # # Adjust the coordinates of the polygon to align with the image's (0, 0) origin
    # adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]
    
    # # Draw the polygon on the image
    # draw.polygon(adjusted_coords, outline=None, fill=fill_colour)
    polygon = wkt.loads(wkt_string)
    minx, miny, maxx, maxy = polygon.bounds
    bounding_box = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
    minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    
    # Create a blank image with a transparent background (RGBA mode)
    width = maxx - minx
    height = maxy - miny
    # print(width, height)
    img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
    draw = ImageDraw.Draw(img)

    # Adjust the coordinates of the polygon to align with the image's (0, 0) origin
    #adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]
    adjusted_bounding_box = [(x - minx, y - miny) for x, y in bounding_box]
    # Draw the polygon on the image
    #draw.polygon(adjusted_coords, outline=None, fill=fill_colour)
    # print(bounding_box)
    # print(adjusted_bounding_box)
    draw.polygon(adjusted_bounding_box, outline=None, fill=fill_colour)
    # img.show()
    # print(jp)
    # Load the brush stroke image
    # Load the brush stroke image
    try:
        brush_stroke = Image.open("brush_stroke.png")
    except Exception as e:
        print(f"Error loading brush stroke image: {e}")
        return current_frame

    # Resize the brush stroke to fit the cropped region size
    resized_image_brush = brush_stroke.resize((width, height))
    
    # Ensure the brush stroke image is in RGBA mode
    if resized_image_brush.mode != 'RGBA':
        resized_image_brush = resized_image_brush.convert('RGBA')

    # Split into individual bands for blending
    base_r, base_g, base_b, base_a = img.split()
    overlay_r, overlay_g, overlay_b, overlay_a = resized_image_brush.split()

    # Multiply the RGB channels of base and overlay
    result_r = Image.composite(ImageChops.multiply(base_r, overlay_r), base_r, overlay_a)
    result_g = Image.composite(ImageChops.multiply(base_g, overlay_g), base_g, overlay_a)
    result_b = Image.composite(ImageChops.multiply(base_b, overlay_b), base_b, overlay_a)

    # Combine the result and use the overlay's alpha channel
    result_image = Image.merge("RGBA", (result_r, result_g, result_b, overlay_a))
    
    # Paste the composite image onto the current frame
    paste_x = min(max(minx, 0), canvas_width - width)
    paste_y = min(max(miny, 0), canvas_height - height)
    current_frame.paste(result_image, (paste_x, paste_y), result_image)  # Use result_image as a mask

    return current_frame

# Load the JSON data
input_json_file = "star_night_fullhd-output_with_attributes.json"
output_video_name = 'star_night_full_output_output_video_bbox.mp4'

# OpenCV VideoWriter setup
fps = 30  # Frames per second
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Codec for .avi format
canvas_width = 1500  # Default canvas width
canvas_height = 1500  # Default canvas height

# Create a VideoWriter object to write frames to the video file
video_writer = cv2.VideoWriter(output_video_name, fourcc, fps, (canvas_width, canvas_height))

# Initialize the current frame with a blank canvas
current_frame = Image.new('RGBA', (canvas_width, canvas_height), color=(0, 0, 0, 255))

# Process each entry in the JSON file and accumulate frames
with open(input_json_file, "r") as json_file:
    data = json.load(json_file)
    print(len(data))
    for idx, row in enumerate(data):
        wkt_string = row.get('wkt_string')
        fill_colour = row.get('fill_colour', "red")  # Default to red if not provided

        # Update the current frame with the new polygon data
        current_frame = process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

        # Convert the current frame to a format suitable for OpenCV (BGR)
        frame = np.array(current_frame)
        frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)

        # Write the frame to the video
        video_writer.write(frame)

        print(f"Processed frame {idx + 1}")

# Release the video writer and finalize the video file
video_writer.release()
print(f"Video created and saved as {output_video_name}")
