import json
from shapely.geometry import Polygon
from PIL import Image, ImageDraw, ImageChops
from shapely import wkt
import os

# Function to process each row in the JSON
def process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, output_image_name, idx, previous_image_name=None):
    # Parse the WKT string into a Shapely Polygon
    polygon = wkt.loads(wkt_string)
    minx, miny, maxx, maxy = polygon.bounds
    minx, miny, maxx, maxy = map(lambda x: round(x), (minx, miny, maxx, maxy))
    
    # Create a blank image with a transparent background (RGBA mode)
    width = maxx - minx
    height = maxy - miny
    img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # Transparent background
    draw = ImageDraw.Draw(img)

    # Adjust the coordinates of the polygon to align with the image's (0, 0) origin
    adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]
    
    # Draw the polygon on the image
    draw.polygon(adjusted_coords, outline=None, fill=fill_colour)

    # Load the brush stroke image
    try:
        brush_stroke = Image.open("brushes/white-color-brush-stroke-for-free-free-vector.png")
    except Exception as e:
        print(f"Error loading brush stroke image: {e}")
        return

    # Resize the brush stroke to fit the cropped region size
    resized_image_brush = brush_stroke.resize((width, height))
    
    # Ensure the brush stroke image is in RGBA mode
    if resized_image_brush.mode != 'RGBA':
        resized_image_brush = resized_image_brush.convert('RGBA')

    # Split into individual bands for blending
    base_r, base_g, base_b, base_a = img.split()
    overlay_r, overlay_g, overlay_b, overlay_a = resized_image_brush.split()

    # Multiply the RGB channels of base and overlay
    result_r = Image.composite(ImageChops.multiply(base_r, overlay_r), base_r, overlay_a)
    result_g = Image.composite(ImageChops.multiply(base_g, overlay_g), base_g, overlay_a)
    result_b = Image.composite(ImageChops.multiply(base_b, overlay_b), base_b, overlay_a)

    # Combine the result and use the overlay's alpha channel
    result_image = Image.merge("RGBA", (result_r, result_g, result_b, overlay_a))
    result_image.show()
    # Create a blank 1024x1024 image to place the composite image onto
    if previous_image_name is None:
        img_1 = Image.new('RGB', (canvas_width, canvas_height), color='white')
    else: 
        try:
            img_1 = Image.open(previous_image_name)
        except Exception as e:
            print(f"Error opening previous image: {e}")
            return

    # Ensure pasting coordinates are within the canvas bounds
    paste_x = min(max(minx, 0), canvas_width - width)
    paste_y = min(max(miny, 0), canvas_height - height)

    # Paste the composite image onto the blank canvas at the position (minx, miny)
    img_1.paste(result_image, (paste_x, paste_y))

    # Save the final image
    img_1.save(output_image_name)
    
    return output_image_name  # Return the name for the next iteration

# Load the JSON data
input_json_file = "dog_10-output_with_attributes.json"
output_dir = 'patch_output'
os.makedirs(output_dir, exist_ok=True)

with open(input_json_file, "r") as json_file:
    data = json.load(json_file)

# Variable to hold the name of the previous image
previous_image_name = None

# Process each entry in the JSON file
for idx, row in enumerate(data):
    wkt_string = row.get('wkt_string')
    fill_colour = row.get('fill_colour', "red")  # Default to red if not provided
    canvas_width = row.get('canvas_width', 1500)  # Default to 1500 if not provided
    canvas_height = row.get('canvas_height', 1500)  # Default to 1500 if not provided
    
    output_image_name = f"{output_dir}/output_image_{idx}.png"
    
    # Call the function to process and create the image
    previous_image_name = process_polygon_data(wkt_string, fill_colour, canvas_width, canvas_height, output_image_name, idx, previous_image_name)

    print(f"Processed and saved image: {output_image_name}")
