from svgpath2mpl import parse_path
from shapely.geometry import Polygon, Point, LineString
from shapely.ops import split
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Polygon as MplPolygon


svg_path_data = "M0,0 L1,4 L3,4 L6,17 L4,17 L4,19 L7,19 L7,16 L12,17 L8,18 L8,20 L12,22 L13,27 L12,30 L18,30 L19,39 L10,39 L6,36 L6,34 L8,34 L7,32 L3,31 L3,28 L0,29 L0,25 L4,27 L6,29 L11,30 L11,28 L8,28 L8,24 L-5,24 L-7,25 L-7,22 L-9,21 L-7,20 L-14,18 L-16,15 L-15,12 L-10,16 L-9,13 L-12,13 L-12,11 L-17,10 L-19,4 L-18,2 L-16,2 L-15,9 L-12,9 L-12,3 L-9,3 L-10,11 L-1,9 Z"
mpl_path = parse_path(svg_path_data)

polygon_vertices = mpl_path.to_polygons()[0]  # Extract vertices from path

# Flip the y-coordinates to match SVG's coordinate direction if necessary
# polygon_vertices[:, 1] = -polygon_vertices[:, 1]

# Create a Shapely polygon from the adjusted vertices
polygon = Polygon(polygon_vertices)

# Find the centroid of the polygon
centroid = polygon.centroid
print(centroid)

# Access all coordinates (including exterior and interior)
coordinates = list(polygon.exterior.coords)

# To account for any possible interior rings (holes), add them as well
for interior in polygon.interiors:
    coordinates.extend(list(interior.coords))

# Find the smallest and farthest x and y-values
min_x = min(coord[0] for coord in coordinates)  # smallest x
max_x = max(coord[0] for coord in coordinates)  # farthest x
min_y = min(coord[1] for coord in coordinates)  # smallest y
max_y = max(coord[1] for coord in coordinates)  # farthest y
print("Smallest:", min_x, min_y)
print("Farthest:", max_x, max_y)

# Calculate midpoints
mid_x_1 = (centroid.x + min_x) / 2
mid_y_1 = (centroid.y + min_y) / 2

mid_x_2 = (centroid.x + max_x) / 2
mid_y_2 = (centroid.y + max_y) / 2

midpoint_1 = Point(mid_x_1, mid_y_1)
midpoint_2 = Point(mid_x_2, mid_y_2)

# Define center lines
center_line_1 = LineString([(centroid.x, min_y), (centroid.x, max_y)])
center_line_1_left = LineString([(midpoint_1.x, min_y), (midpoint_1.x, max_y)])
center_line_1_right = LineString([(midpoint_2.x, min_y), (midpoint_2.x, max_y)])

center_line_2 = LineString([(min_x, centroid.y), (max_x, centroid.y)])
center_line_2_left = LineString([(min_x, midpoint_1.y), (max_x, midpoint_1.y)])
center_line_2_right = LineString([(min_x, midpoint_2.y), (max_x, midpoint_2.y)])


# Split the Shapely polygon using the first line
result_center_line_1 = split(polygon, center_line_1)

# Split each resulting polygon with the second line
result_center_line_1_left = []
for part in result_center_line_1.geoms:
    result_center_line_1_left.extend(split(part, center_line_1_left).geoms)

# Split the resulting polygons further with the third line
result_center_line_1_right = []
for part in result_center_line_1_left:
    result_center_line_1_right.extend(split(part, center_line_1_right).geoms)

result_center_line_2 = []
for part in result_center_line_1_right:
    result_center_line_2.extend(split(part, center_line_2).geoms)

result_center_line_2_left = []
for part in result_center_line_2:
    result_center_line_2_left.extend(split(part, center_line_2_left).geoms)

result_center_line_2_right = []
for part in result_center_line_2_left:
    result_center_line_2_right.extend(split(part, center_line_2_right).geoms)

# Check if the split occurs
if not result_center_line_2_right:  # Checks if the list is empty
    print("Final result is empty.")
else:
    # Plot the original polygon and the split polygons
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))

    # Plot the original polygon
    axes[0].add_patch(MplPolygon(np.array(polygon.exterior.coords), closed=True, edgecolor='black', facecolor='lightgray'))
    axes[0].set_xlim(min(polygon_vertices[:, 0]) - 10, max(polygon_vertices[:, 0]) + 10)
    axes[0].set_ylim(min(polygon_vertices[:, 1]) - 10, max(polygon_vertices[:, 1]) + 10)
    axes[0].set_aspect('equal')
    axes[0].set_title("Original Polygon")
    axes[0].legend()

    # Plot the split polygons
    for i, part in enumerate(result_center_line_2_right):  # Use `geoms` to iterate GeometryCollection
        print(f"Polygon {i}: {part.wkt}")  # Print WKT of the split polygon for debugging
        part_patch = MplPolygon(np.array(part.exterior.coords), closed=True, edgecolor='black', facecolor=np.random.rand(3,))
        axes[1].add_patch(part_patch)

    axes[1].set_xlim(min(polygon_vertices[:, 0]) - 10, max(polygon_vertices[:, 0]) + 10)
    axes[1].set_ylim(min(polygon_vertices[:, 1]) - 10, max(polygon_vertices[:, 1]) + 10)
    axes[1].set_aspect('equal')
    axes[1].set_title("Split Polygons")

    plt.tight_layout()
    plt.show()
