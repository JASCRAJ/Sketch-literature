import os
import subprocess
import sys

# import os

# folder_name = "kids_paint_5"

# files_no_ext = [
#     os.path.splitext(f)[0]
#     for f in os.listdir(folder_name)
#     if os.path.isfile(os.path.join(folder_name, f))
# ]

# print(files_no_ext)

# for file_name in files_no_ext:
file_name = "kids_paint_5"

folder_name = "kids_paint_5"
input_folder = f"sam_outputs/{folder_name}/{file_name}"#f"sam_outputs/{filename}"
output_folder = f"input_svg/{folder_name}/{file_name}"
#os.makedirs(input_folder, exist_ok=True)
os.makedirs(output_folder, exist_ok=True)  # Ensure output directory exists
print(input_folder)

# for file in os.listdir(input_folder):
#     if file.lower().endswith((".png", ".jpg", ".jpeg")):
#         input_path = os.path.join(input_folder, file)
#         output_path = os.path.join(output_folder, "vtrace-" + file.rsplit(".", 1)[0] + ".svg")
        
#         cmd = [
#             "vtracer.exe",  # If vtracer.exe is in the same folder
#             "--input", input_path,
#             "--output", output_path,
#             "--hierarchical", "cutout",
#             #"-f", "0",
#             # "-f", "0",
#             "-p", "8",
#             # "-g", "0",#"-g", "0",
#             # "-m", "spline",
#             # "-l", "3.5",#"-l", "3.5",
#             # "-s", "45",
#             # "-p", "8",
#             # "-g", "12",
#             # "-m", "spline",
#             # "-l", "3.5"
#         ]
#         subprocess.run(cmd, check=True)

for file in os.listdir(input_folder):
    if file.lower().endswith((".png", ".jpg", ".jpeg")):
        input_path = os.path.join(input_folder, file)
        output_path = os.path.join(output_folder, "vtrace-" + file.rsplit(".", 1)[0] + ".svg")
        
        cmd = [
            "vtracer.exe",  # If vtracer.exe is in the same folder
            "--input", input_path,
            "--output", output_path,
            "--hierarchical", "cutout",
            #"-f", "0",
            "-f", "0",
            "-p", "8",
            "-g", "12",
            "-m", "spline",
            "-l", "3.5",
            "-s", "0",
            # "-p", "8",
            # "-g", "12",
            #"-m", "spline",
            #"-l", "3.5"
        ]

        
        subprocess.run(cmd, check=True)
