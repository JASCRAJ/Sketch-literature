import xml.etree.ElementTree as ET
import svgwrite
import io
from cairosvg import svg2png
from PIL import Image
import imageio
import numpy as np

def extract_svg_paths(svg_file):
    tree = ET.parse(svg_file)
    root = tree.getroot()
    paths = []
    for elem in root.iter():
        tag = elem.tag.lower()
        if tag.endswith('path') and 'd' in elem.attrib:
            paths.append(elem.attrib['d'])
    return paths

def svg_strokes_to_video_from_file(svg_file, output_video="output.mp4", fps=10, canvas_size=(512, 512)):
    paths = extract_svg_paths(svg_file)

    frames = []
    for i in range(1, len(paths)+1):
        dwg = svgwrite.Drawing(size=canvas_size)
        for d in paths[:i]:
            dwg.add(dwg.path(d=d, stroke="black", fill="none", stroke_width=2))
        
        svg_data = dwg.tostring()

        # Render SVG to PNG (in-memory)
        png_bytes = svg2png(bytestring=svg_data, output_width=canvas_size[0], output_height=canvas_size[1])
        image = Image.open(io.BytesIO(png_bytes)).convert("RGB")
        frames.append(np.array(image))

    # Write all frames to video
    with imageio.get_writer(output_video, fps=fps) as writer:
        for frame in frames:
            writer.append_data(frame)

    print(f"✅ Video saved to {output_video}")

svg_strokes_to_video_from_file("sequence-vtrace-head_crop_0.svg", output_video="strokes_animation.mp4", fps=12)
