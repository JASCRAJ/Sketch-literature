import json
import numpy as np
from PIL import Image
from shapely.geometry import Polygon
import math
import os
from PIL import Image, ImageDraw, ImageChops, ImageFilter

# Load stroke data
with open('results/metface/130_stroke_params.json', 'r') as file:
    stroke_data = json.load(file)

# # Load stroke data
# with open('composite_reflection_corrected.json', 'r') as file:
#     color_data = json.load(file)

# Read canvas size
canvas_width = int(stroke_data[0]['canvas_width'])
canvas_height = int(stroke_data[0]['canvas_height'])

# Create blank RGBA image
output_image = Image.new("RGBA", (canvas_width, canvas_height))

# Dataset path
data_path = 'Picasso/'

# Load stroke indexes
# indexes = np.load('indexes.npy')
#print(indexes[:5])
# Iterate through stroke indexesx
index_name = "fill_colour"
for j in range(len(stroke_data)):
    #idx = indexes[j]
    #print(j)
    # Step 1: Load polygon points
    bbox_points = [tuple(pt) for pt in stroke_data[j]['bbox']]
    #print(bbox_points)
    polygon = Polygon(bbox_points)
    if (polygon.area>400):
        print(j, polygon.area)
    if not polygon.is_valid or not polygon.exterior:
        continue

    x, y = polygon.exterior.coords.xy
    #print(x, y)
     # Step 5: Determine position to paste
    min_x = min(x[:-1])  # exclude closing point
    min_y = min(y[:-1])
    max_x = max(x[:-1])
    max_y = max(y[:-1])
    width1 = max_x - min_x
    height1 = max_y - min_y
    # Step 2: Calculate width and height from edge lengths
    if len(x) < 4:
        continue  # not enough points

    width_brush = int(math.hypot(x[1] - x[0], y[1] - y[0]))
    height_brush = int(math.hypot(x[2] - x[1], y[2] - y[1]))
    #print(width1, height1, width_brush, height_brush)
    if width_brush < 1 or height_brush < 1:
        print(f"Skipping stroke {j} due to invalid dimensions")
        continue

    # Step 3: Load brush stroke image
    # image_idx = indexes[j]
    # brush_path = os.path.join(data_path, f"{image_idx}.jpg")
    # if not os.path.exists(brush_path):
    #     print(f"Missing brush image: {brush_path}")
    #     continue

    #brush_stroke = Image.open("brush_7.png").convert("RGBA")
    # brush_stroke = Image.open(brush_path).convert("RGBA")
    adjusted_coords = [(x - min_x, y - min_y) for x, y in bbox_points]
    # resized_brush = brush_stroke.resize((width_brush, height_brush))
    img = Image.new('RGBA', (int(width1), int(height1)), (0, 0, 0, 0))  # Transparent background
    draw = ImageDraw.Draw(img)
    color = stroke_data[j][index_name]
    # #print(color)

    # # If it's a string, convert it using eval (only if you're sure it's safe)
    # if isinstance(color, str):
    #     color = eval(color)  # Safer alternative below

    # # If it's a list, convert to tuple
    # if isinstance(color, list):
    #     color = tuple(color)
    
    draw.polygon(adjusted_coords, outline=None, fill=color, width=5)
    #img.show()
    #draw.polygon(adjusted_coords, outline= None, fill=color_data[j]['Retrieved Image Dominant Color'], width=5)
    #img.show()
    # Step 4: Rotate brush stroke
    # angle = stroke_data[j].get('angle', 0)
    # rotated_image = resized_brush.rotate(-angle, expand=True)

   

    # rotated_brush = Image.new('RGBA', (int(width1), int(height1)), (0, 0, 0, 0))

    # # 6. Paste the rotated image into the final image (no clipping)
    # rotated_brush.paste(rotated_image, (0,0), rotated_image)

    # base_r, base_g, base_b, base_a = img.split()
    # overlay_r, overlay_g, overlay_b, overlay_a = rotated_brush.split()

    # # Multiply the RGB channels of base and overlay
    # result_r = Image.composite(ImageChops.multiply(base_r, overlay_r), base_r, overlay_a)
    # result_g = Image.composite(ImageChops.multiply(base_g, overlay_g), base_g, overlay_a)
    # result_b = Image.composite(ImageChops.multiply(base_b, overlay_b), base_b, overlay_a)

    # # Combine the result and use the overlay's alpha channel
    # result_image = Image.merge("RGBA", (result_r, result_g, result_b, overlay_a))
    #rotated_brush.show()
    paste_x = min(max(min_x, 0), canvas_width - width1)
    paste_y = min(max(min_y, 0), canvas_height - height1)
    #print (min_x, min_y)
    #print(paste_x, paste_y)
    #rotated_brush.show()
    # Step 6: Paste onto canvas
    output_image.paste(img, (int(paste_x), int(paste_y)), img)
    #output_image.show()

# Save final output
output_image.save(f'1_stroke_params-{index_name}.png')
print(f"Saved as {index_name}.png")
