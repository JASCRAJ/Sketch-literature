import os
import glob, os
#os.system('pip install colorthief')
from PIL import Image
import numpy as np
import torch
import torchvision
import glob
import numpy as np
import shutil
from torchvision.io import read_image 
from torchvision.utils import make_grid
from torchvision.transforms import ToTensor
import time
import json
import math
from colorthief import ColorThief

#Get Dominant color for border and create image with border
def resize_border(path_var,seg_path,width,height):
    orig_image=Image.open(path_var).convert('RGBA')
    color_thief=ColorThief(seg_path)
    dominant_color=color_thief.get_color(quality=7)
    aspect_ratio= orig_image.height/orig_image.width
    if orig_image.height > orig_image.width and height > width:
        new_width=width
        new_height=round(new_width*aspect_ratio)
    elif orig_image.height < orig_image.width and height > width:
        orig_image=orig_image.rotate(90)
        aspect_ratio= orig_image.height/orig_image.width
        new_width=width
        new_height=round(new_width*aspect_ratio)
    elif orig_image.height < orig_image.width and height < width:

        new_height=height
        new_width=round(new_height/aspect_ratio)
    else:
        orig_image=orig_image.rotate(90)
        aspect_ratio= orig_image.height/orig_image.width

        new_height=height
        new_width=round(new_height/aspect_ratio)
    resized_image=orig_image.resize((new_width,new_height))
    old_size=resized_image.size
    new_size=(width,height)
    new_im=Image.new("RGBA", new_size, color=dominant_color)
    box=tuple((n-o)//2 for n, o in zip(new_size,old_size))
    new_im.paste(resized_image, box,resized_image)
    return new_im


image=Image.open('Input.png').convert("RGBA") #Original Image
retrievals='retrievals/' #Retrieval location
no_of_ret=[file for file in glob.glob(retrievals+'*.jpg')]#Number of retrievals
collage_save_path='Head_Crop/'#Save Location for the collage
input_loc='patches/'#Location for the patches
#Masked image scaled up

V=20
masked_image = Image.new("RGBA", (image.size[0]*V,image.size[1]*V))

stroke_data=None

#Stroke file location same as save_path
with open('strokes.json','r') as file:
    stroke_data=json.load(file)

import cv2

# Prepare video writer

fps = 10  # adjust speed
video_path = f"head_crop_{fps}_fps.mp4"
fourcc = cv2.VideoWriter_fourcc(*"mp4v")
video_writer = cv2.VideoWriter(video_path, fourcc, fps, (masked_image.width, masked_image.height))


for j in range(len(no_of_ret)):
    print(j)
    polygon=stroke_data[j]['bbox']
    for i in range(len(polygon)):
        polygon[i]=tuple(polygon[i])
    
    min_x = int(min(p[0] for p in polygon)) * V
    max_x = int(max(p[0] for p in polygon)) * V
    min_y = int(min(p[1] for p in polygon))* V
    max_y = int(max(p[1] for p in polygon)) * V

    width_brush = math.floor(((polygon[1][0] - polygon[0][0])**2 + (polygon[1][1] - polygon[0][1])**2)**0.5) * V
    height_brush = math.floor(((polygon[2][0] - polygon[1][0])**2 + (polygon[2][1] - polygon[1][1])**2)**0.5) * V
    #Check if width or height is less than 1 pixel
    if width_brush < 1 or height_brush < 1:
        continue
    #Check if segment is completely transparent
    elif np.array(Image.open(input_loc+str(j)+'.png').convert('RGB')).max()==0:
        continue
    else:
        #Retrieved image with border
        ret_image=resize_border(retrievals+str(j)+'.jpg',input_loc+str(j)+'.png',width_brush,height_brush).rotate(angle=-stroke_data[j]['angle'],expand=True)
        width1 = max_x - min_x
        height1 = max_y - min_y
        rotated_brush = Image.new('RGBA', (int(width1), int(height1)), (0, 0, 0, 0))
        rotated_brush.paste(ret_image, (0,0), ret_image)
        resized_brush = rotated_brush.resize((2500, 2500), resample=Image.Resampling.LANCZOS)
        #resized_brush.show()
        masked_image.paste(rotated_brush,(min_x,min_y),rotated_brush)
        masked_image.paste(resized_brush, (0, 0), resized_brush)
        frame_bgr = cv2.cvtColor(np.array(masked_image.convert("RGB")), cv2.COLOR_RGB2BGR)
        video_writer.write(frame_bgr)
        #masked_image.show()
        #print(jp)
masked_image.save('output.png')
