import json
import os
import math
import numpy as np
from shapely import wkt

folder_name = "kids_paint_5"

filename = "kids_paint_5"
folder_path = os.path.join("results", folder_name)
os.makedirs(folder_path, exist_ok=True)

grid_size = 2
ngroup = 30
# files_no_ext = [
#     os.path.splitext(f)[0]
#     for f in os.listdir(folder_name)
#     if os.path.isfile(os.path.join(folder_name, f))
# ]
# os.makedirs(f"json/{folder_name}", exist_ok=True)
# for filename in files_no_ext:
INPUT_JSON_FILE = f"json/{folder_name}/{filename}_{grid_size}_{ngroup}-combined-dsequence-with_attributes.json" #
#INPUT_JSON_FILE = f"json/{folder_name}/{filename}-combined-dsequence-with_attributes.json"
OUTPUT_JSON_FILE = f"results/{folder_name}/{filename}{ngroup}_stroke_params.json"
OUTPUT_NPZ_FILE = f"results/{folder_name}/{filename}{ngroup}_stroke_params.npz"

with open(INPUT_JSON_FILE, 'r') as file:
    data_1 = json.load(file)

first_entry = data_1[0]
canvas_width = int(float(first_entry["canvas_width"]))
canvas_height = int(float(first_entry["canvas_height"]))

def get_angle(p1, p2):
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    return math.degrees(math.atan2(dy, dx))

all_strokes = []

for idx, row in enumerate(data_1):
    stroke_info = {}
    wkt_string = row.get('wkt_string')
    fill_colour = row.get('fill_colour', "None")
    data_segment = row.get('segment_id')
    polygon = wkt.loads(wkt_string)
    # if polygon.area > 1000:
    #     print(polygon.area)
    minx, miny, maxx, maxy = polygon.bounds
    width = maxx - minx
    height = maxy - miny

    if width < 2 or height < 2:
        continue  # Skip small strokes

    rotated_rectangle = polygon.minimum_rotated_rectangle
    # if rotated_rectangle.area > 1000:
    #     print(idx, "rotated_rectangle", rotated_rectangle.area)
    rotated_box_coords = list(rotated_rectangle.exterior.coords[:-1])  # Remove last duplicate point

    if len(rotated_box_coords) < 2:
        continue
    angle = get_angle(rotated_box_coords[0], rotated_box_coords[1])
    stroke_info['angle'] = angle
    stroke_info['index'] = idx
    stroke_info['bbox'] = rotated_box_coords
    stroke_info['canvas_width'] = canvas_width
    stroke_info['canvas_height'] = canvas_height
    stroke_info['fill_colour'] = fill_colour
    stroke_info['segment_id'] = data_segment
    all_strokes.append(stroke_info)

# # Save to JSON
with open(OUTPUT_JSON_FILE, 'w') as out_file:
    json.dump(all_strokes, out_file, indent=2)

# Optional: Save to NPZ (carefully)
#np.savez(OUTPUT_NPZ_FILE, strokes=np.array(all_strokes, dtype=object))


print(f"Saved stroke parameters to:\n- {OUTPUT_JSON_FILE}\n- {OUTPUT_NPZ_FILE}")
