import json
import numpy as np
from PIL import Image
from shapely.geometry import Polygon
import math
# Load stroke data
with open('strokes.json', 'r') as file:
    stroke_data = json.load(file)

# Read canvas size
canvas_width = int(stroke_data[0]['canvas_width'])
canvas_height = int(stroke_data[0]['canvas_height'])

# Create blank RGBA image
output_image = Image.new("RGBA", (canvas_width, canvas_height))

# Dataset path
data_path = 'Picasso/'

# Load stroke indexes
indexes = np.load('indexes.npy')


for j in range(len(indexes)):
    #Loading Polygon data
    polygon=stroke_data[j]['bbox']
    for i in range(len(polygon)):
        polygon[i]=tuple(polygon[i])
    #mask = Image.new('L', image.size, 0)
    bbox_points = [tuple(pt) for pt in stroke_data[j]['bbox']]  # 4 points
    rotated_box_coords = Polygon(bbox_points)
    area = rotated_box_coords.area
    print(area)
    x, y = rotated_box_coords.exterior.coords.xy
    min_x = min(x for x, y in rotated_box_coords)
    min_y = min(y for x, y in rotated_box_coords)
    max_x = max(x for x, y in rotated_box_coords)
    max_y = max(y for x, y in rotated_box_coords)
    width1 = max_x - min_x
    height1 = max_y - min_y
    width_brush = math.floor(((x[1] - x[0])**2 + (y[1] - y[0])**2)**0.5)
    height_brush = math.floor(((x[2] - x[1])**2 + (y[2] - y[1])**2)**0.5)
    if width_brush < 1 or height_brush < 1:
        print("Width and height must be >= 2. Skipping resize operation.")
        #return current_frame
    brush_stroke=Image.open(data_path+str(indexes[j])+'.jpg').convert('RGBA')
    resized_image = brush_stroke.resize((width_brush, height_brush))
    rotated_image = resized_image.rotate(-stroke_data[j]['angle'], expand=True)
    #print(angle)
    # 5. Create a new transparent background to hold the rotated image
    rotated_brush = Image.new('RGBA', (int(width1), int(height1)), (0, 0, 0, 0))

    # 6. Paste the rotated image into the final image (no clipping)
    rotated_brush.paste(rotated_image, (0,0), rotated_image)
    rotated_brush.show()
    paste_x = min(max(min_x, 0), canvas_width - width1)
    paste_y = min(max(min_y, 0), canvas_height - height1)
    output_image.paste(rotated_brush,(paste_x,paste_y),rotated_brush)
output_image.save('Border_Image_Resized.png')