from PIL import Image
import os

# Define folder paths
base_folder = "Composite_reflection-inputs"
imgs_folder = os.path.join(base_folder, "imgs")
sketches_folder = os.path.join(base_folder, "sketches")
sketches_bw_folder = os.path.join(base_folder, "sketches_bw")

# Ensure output directory exists
os.makedirs(sketches_bw_folder, exist_ok=True)

# Process each image in the imgs folder
for file in os.listdir(imgs_folder):
    if file.endswith(".jpg"):  # Only process JPG files
        file_name = os.path.splitext(file)[0]  # Get filename without extension

        # Paths for original image, sketch, and output BW sketch
        image1_path = os.path.join(imgs_folder, f"{file_name}.jpg")
        image2_path = os.path.join(sketches_folder, f"{file_name}.png")
        image2_bw_path = os.path.join(sketches_bw_folder, f"{file_name}.png")

        # Check if sketch exists
        if not os.path.exists(image2_path):
            print(f"Skipping {file_name}: Sketch not found in 'sketches' folder.")
            continue

        # Load the original image and sketch
        image1 = Image.open(image1_path)
        image2 = Image.open(image2_path)

        # Resize sketch to match the original image if dimensions differ
        if image1.size != image2.size:
            image2 = image2.resize(image1.size)

        # Convert to grayscale and apply binary threshold
        threshold = 180  # Adjust threshold as needed
        binary_image = image2.convert("L").point(lambda p: 255 if p > threshold else 0)

        # Save the black-and-white sketch
        binary_image.save(image2_bw_path)

        print(f"Processed and saved: {image2_bw_path}")
