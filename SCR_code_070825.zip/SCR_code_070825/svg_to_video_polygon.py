# # import os
# # import imageio
# # import xml.etree.ElementTree as ET
# # import matplotlib.pyplot as plt
# # from svgpath2mpl import parse_path
# # from shapely.geometry import Polygon
# # from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
# # from matplotlib.figure import Figure
# # from io import BytesIO
# # import numpy as np
# # import cv2
# # # Config

# # video_out  = "output.mp4"
# # canvas_size = (1024, 1024)       # Width x Height
# # fps = 30    

# # # Load SVG content
# # def load_svg_paths(svg_file):
# #     tree = ET.parse(svg_file)
# #     root = tree.getroot()
# #     paths = []

# #     for elem in root.findall(".//{http://www.w3.org/2000/svg}path"):
# #         d = elem.attrib.get("d")
# #         transform = elem.attrib.get("transform", "")
# #         fill = elem.attrib.get("fill", "#000000")
# #         paths.append((d, transform, fill))
# #     return paths

# # # Parse transform like: "translate(x,y)"
# # def parse_transform(transform_str):
# #     if "translate" in transform_str:
# #         parts = transform_str.strip().replace("translate(", "").replace(")", "").split(",")
# #         return float(parts[0]), float(parts[1])
# #     return 0.0, 0.0

# # # Main function to convert strokes to video
# # def svg_to_video(svg_path, output_video="output.mp4", canvas_size=(512, 512)):
# #     paths = load_svg_paths(svg_path)
# #     frames = []

# #     fig, ax = plt.subplots()
# #     fig.set_size_inches(5.12, 5.12)  # For 512x512 at 100 DPI
# #     ax.set_xlim(0, canvas_size[0])
# #     ax.set_ylim(0, canvas_size[1])
# #     ax.set_facecolor("white")
# #     ax.invert_yaxis()  # SVG y-axis is top-down

# #     # For each path, draw and store frame
# #     for i, (d, transform, fill) in enumerate(paths):
# #         mpl_path = parse_path(d)
# #         tx, ty = parse_transform(transform)
# #         transformed_vertices = mpl_path.vertices + [tx, ty]
# #         polygon = Polygon(transformed_vertices)

# #         patch = plt.Polygon(np.array(polygon.exterior.coords), closed=True, facecolor=fill, edgecolor=None)
# #         ax.add_patch(patch)

# #         # Convert canvas to image in memory
# #         buf = BytesIO()
# #         fig.canvas.draw()
# #         image = np.frombuffer(fig.canvas.tostring_rgb(), dtype='uint8')
# #         image = image.reshape(fig.canvas.get_width_height()[::-1] + (3,))
# #         frames.append(image)

# #         print(f"✔️ Frame {i+1}/{len(paths)} added.")

# #     plt.close(fig)

# #     # Save video from frames
# #     imageio.mimsave(output_video, frames, fps=10)
# #     print(f"🎬 Video saved to {output_video}")
# # svg_to_video(svg_file, "output.mp4")


# import xml.etree.ElementTree as ET
# from svgpath2mpl import parse_path
# from shapely.geometry import Polygon, box
# import json
# import re
# import numpy as np
# import os
# import json
# import cv2
# from shapely.geometry import Polygon, box
# from PIL import Image, ImageDraw, ImageChops, ImageFilter
# from shapely import wkt, Point
# import numpy as np
# import math
# from sklearn.decomposition import PCA
# import os

# import time

# svg_file  = "output_svg/kids_paint/sketches_bw/sequence-vtrace-input_6.svg"
# output_data = []
# def extract_fill_colour(style):
#         match = re.search(r'fill:\s*([^;]+)', style)
#         if match:
#             return match.group(1)
#         return None
# def apply_transform(vertices, transform):
#         vertices = np.array(vertices)
#         if transform and "translate" in transform:
#             match = re.search(r"translate\(([^,]+),\s*([^\)]+)\)", transform)
#             if match:
#                 tx, ty = map(float, match.groups())
#                 vertices[:, 0] += tx
#                 vertices[:, 1] += ty
#         return vertices
# def extract_svg_paths_with_attributes(svg_file):
#         tree = ET.parse(svg_file)
#         root = tree.getroot()
#         namespace = {'svg': 'http://www.w3.org/2000/svg'}
#         path_data = []
#         viewbox = root.attrib.get("viewBox")

#         if viewbox:
#             min_x, min_y, width, height = map(int, viewbox.split())
#         else:
#             width = root.attrib.get("width", "1500").replace("px", "").strip()
#             height = root.attrib.get("height", "1500").replace("px", "").strip()

#         for path in root.findall('.//svg:path', namespace):
#             svg_path_data = path.get('d')
#             transform = path.get('transform')
#             #style = path.get('style')
#             fill_colour = path.get('fill')
#             #fill_colour = extract_fill_colour(style)
#             #print(transform)
#             #print(fill_colour)
#             if svg_path_data:
#                 path_data.append({
#                     'path': svg_path_data,
#                     'transform': transform,
#                     #'style': style,
#                     'fill_colour': fill_colour,
#                     'width': width,
#                     'height': height
#                 })
#         return path_data

# svg_data = extract_svg_paths_with_attributes(svg_file)

# for data in svg_data:
#     svg_path_data = data['path']
#     transform = data['transform']
#     #style = data['style']
#     fill_colour = data['fill_colour']
#     width = data['width']
#     height = data['height']

#     mpl_path = parse_path(svg_path_data)
#     polygons = mpl_path.to_polygons()

#     for poly in polygons:
#         transformed_poly = apply_transform(poly, transform)
#         shapely_polygon = Polygon(transformed_poly)
#         output_data.append({
#             'wkt_string': shapely_polygon.wkt,
#             #'path': data['path'],
#             'transform': transform,
#             #'style': style,
#             'fill_colour': fill_colour,
#             'canvas_width': width,
#             'canvas_height': height
#         })

# def process_polygon_data(idx, wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
#     # Parse the WKT string into a Shapely Polygon

#     polygon = wkt.loads(wkt_string)
#     #vertices = list(polygon.exterior.coords)
#     minx, miny, maxx, maxy = polygon.bounds
    
#     width = maxx - minx
#     height = maxy - miny
#     if width < 2 or height < 2:
#         print("Width and height must be >= 2. Skipping resize operation.")
#         return current_frame
#     rotated_rectangle = polygon.minimum_rotated_rectangle
#     # Extract the rectangle's coordinates and calculate width and height
#     x, y = rotated_rectangle.exterior.coords.xy
#     rotated_box_coords = list(rotated_rectangle.exterior.coords[:-1])  # Exclude duplicate last point
#     min_x = min(x for x, y in rotated_box_coords)
#     min_y = min(y for x, y in rotated_box_coords)
#     max_x = max(x for x, y in rotated_box_coords)
#     max_y = max(y for x, y in rotated_box_coords)
#     width1 = max_x - min_x
#     height1 = max_y - min_y
    
#     adjusted_coords = [(x - min_x, y - min_y) for x, y in rotated_box_coords]

#     img = Image.new('RGBA', (int(width1), int(height1)), (0, 0, 0, 0))  # Transparent background
#     draw = ImageDraw.Draw(img)
#     draw.polygon(adjusted_coords, outline= None, fill=fill_colour)
#     paste_x = min(max(min_x, 0), canvas_width - width1)
#     paste_y = min(max(min_y, 0), canvas_height - height1)
#     current_frame.paste(img, (int(paste_x), int(paste_y)), img)  # Use result_image as a mask
#     return current_frame


# for idx, row in enumerate(output_data):
#     wkt_string = row.get('wkt_string')
#     fill_colour = row.get('fill_colour', "red")
#     current_frame = process_polygon_data(idx, wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

#     frame = np.array(current_frame)
#     frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
    
#     if idx == len(data_1) - 1:
#         current_frame.save(LAST_FRAME_OUTPUT)
#         print(f"Image created and saved as {LAST_FRAME_OUTPUT}")

#     video_writer.write(frame)
#     #print(f"Processed frame {idx + 1}")

# video_writer.release()
# print(f"Video created and saved as {OUTPUT_VIDEO_NAME}")
import os
import re
import xml.etree.ElementTree as ET
from svgpath2mpl import parse_path
from shapely.geometry import Polygon
from shapely import wkt
import numpy as np
from PIL import Image, ImageDraw
import cv2

# ========== CONFIGURATION ==========
#svg_file = "output_svg/kids_paint/sketches_bw/sequence-vtrace-input_6.svg"
filename = "kids_paint"
mode = "color" #color
#svg_file = f"output_svg/combined/sketch/{filename}-combined-sequence.svg"
svg_file = f"output_svg/sketches/sequence-vtrace-{filename}.svg"
LAST_FRAME_OUTPUT = f"last_frame-{filename}.png"
OUTPUT_VIDEO_NAME = f"{filename}_{mode}_video.mp4"
fps = 1
# ===================================

# Apply translation from SVG 'transform' attribute
def apply_transform(vertices, transform):
    vertices = np.array(vertices)
    if transform and "translate" in transform:
        match = re.search(r"translate\(([^,]+),\s*([^\)]+)\)", transform)
        if match:
            tx, ty = map(float, match.groups())
            vertices[:, 0] += tx
            vertices[:, 1] += ty
    return vertices

# Extract path data from SVG
def extract_svg_paths_with_attributes(svg_file):
    tree = ET.parse(svg_file)
    root = tree.getroot()
    namespace = {'svg': 'http://www.w3.org/2000/svg'}
    path_data = []

    viewbox = root.attrib.get("viewBox")
    if viewbox:
        min_x, min_y, width, height = map(float, viewbox.split())
    else:
        width = float(root.attrib.get("width", "1500").replace("px", "").strip())
        height = float(root.attrib.get("height", "1500").replace("px", "").strip())

    for path in root.findall('.//svg:path', namespace):
        svg_path_data = path.get('d')
        transform = path.get('transform')
        fill_colour = path.get('fill')  # Default to black if missing
        if svg_path_data:
            path_data.append({
                'path': svg_path_data,
                'transform': transform,
                'fill_colour': fill_colour,
                'width': width,
                'height': height
            })
    return path_data

# # Draw the polygon on the canvas
# def process_polygon_data(idx, wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
#     polygon = wkt.loads(wkt_string)
#     if polygon.is_empty or not polygon.is_valid:
#         print(f"⚠️ Skipping invalid or empty polygon at index {idx}")
#         return current_frame

#     minx, miny, maxx, maxy = polygon.bounds
#     width = maxx - minx
#     height = maxy - miny
#     if width < 2 or height < 2:
#         print(f"⚠️ Polygon too small at index {idx}")
#         return current_frame

#     rotated_rectangle = polygon.minimum_rotated_rectangle
#     coords = list(rotated_rectangle.exterior.coords)[:-1]
#     min_x = min(x for x, y in coords)
#     min_y = min(y for x, y in coords)
#     max_x = max(x for x, y in coords)
#     max_y = max(y for x, y in coords)
#     width1 = max_x - min_x
#     height1 = max_y - min_y
#     adjusted_coords = [(x - min_x, y - min_y) for x, y in coords]

#     img = Image.new('RGBA', (int(np.ceil(width1)), int(np.ceil(height1))), (0, 0, 0, 0))
#     draw = ImageDraw.Draw(img)
#     draw.polygon(adjusted_coords, outline=None, fill=fill_colour)

#     paste_x = int(min(max(min_x, 0), canvas_width - width1))
#     paste_y = int(min(max(min_y, 0), canvas_height - height1))
#     current_frame.paste(img, (paste_x, paste_y), img)

#     return current_frame

val = 27
def process_polygon_data(idx, wkt_string, fill_colour, canvas_width, canvas_height, current_frame):
    polygon = wkt.loads(wkt_string)

    if polygon.is_empty or not polygon.is_valid:
        print(f"⚠️ Skipping invalid or empty polygon at index {idx}")
        return current_frame

    # Get the bounding box for cropping
    minx, miny, maxx, maxy = polygon.bounds
    width = maxx - minx
    height = maxy - miny
    if width < 2 or height < 2:
        print(f"⚠️ Polygon too small at index {idx}")
        return current_frame

    # Adjust the polygon coordinates to top-left origin
    adjusted_coords = [(x - minx, y - miny) for x, y in polygon.exterior.coords]

    # Create an image just large enough to hold the shape
    img = Image.new('RGBA', (int(np.ceil(width)), int(np.ceil(height))), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.polygon(adjusted_coords, outline=None, fill=fill_colour)
    #img.show()
    # Paste the image onto the main canvas
    paste_x = int(min(max(minx, 0), canvas_width - width))
    paste_y = int(min(max(miny, 0), canvas_height - height))
    current_frame.paste(img, (paste_x, paste_y), img)
    #print(jp)
    # if idx == val:
    #     img.show()
    #     current_frame.show()
    return current_frame

# ===== Main Execution =====
svg_data = extract_svg_paths_with_attributes(svg_file)

# Get canvas size from SVG metadata
canvas_width = int(float(svg_data[0]['width']))
canvas_height = int(float(svg_data[0]['height']))
output_data = []

# Convert SVG path to WKT Polygon
for data in svg_data:
    svg_path_data = data['path']
    transform = data['transform']
    fill_colour = data['fill_colour']
    mpl_path = parse_path(svg_path_data)
    polygons = mpl_path.to_polygons()

    for poly in polygons:
        transformed_poly = apply_transform(poly, transform)
        shapely_polygon = Polygon(transformed_poly)
        output_data.append({
            'wkt_string': shapely_polygon.wkt,
            'transform': transform,
            'fill_colour': fill_colour,
            'canvas_width': data['width'],
            'canvas_height': data['height']
        })

current_frame = Image.new('RGBA', (canvas_width, canvas_height), (255, 255, 255, 255))
video_writer = cv2.VideoWriter(
    OUTPUT_VIDEO_NAME,
    cv2.VideoWriter_fourcc(*'mp4v'),
    fps,
    (canvas_width, canvas_height)
)

# print(svg_data[val])
# #print(output_data[27]['wkt_string'])
# print(output_data[val])
# import json
# output_json_svg = "svg_data.json"

# with open(output_json_svg, "w") as f:
#     json.dump(svg_data, f, indent=4)

# print(f"SVG data saved to {output_json_svg}")

# output_json_poly = "output_json_poly.json"

# with open(output_json_poly, "w") as f:
#     json.dump(output_data, f, indent=4)

# print(f"SVG data saved to {output_json_poly}")

# Render each shape frame-by-frame
for idx, row in enumerate(output_data):
    
    wkt_string = row['wkt_string']
    fill_colour = row.get('fill_colour')
    if idx==val:
        print(wkt_string)
    #print(JP)
    #print(fill_colour)
    #print(canvas_width, canvas_height)
    current_frame = process_polygon_data(idx, wkt_string, fill_colour, canvas_width, canvas_height, current_frame)

    frame = np.array(current_frame)
    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
    video_writer.write(frame_bgr)

    print(f"✅ Frame {idx+1}/{len(output_data)} added.")

    if idx == len(output_data) - 1:
        current_frame.save(LAST_FRAME_OUTPUT)
        print(f"🖼️ Last frame saved as {LAST_FRAME_OUTPUT}")
        # Add 30 copies of the final frame to create pause at end
        for i in range(60):
            video_writer.write(frame_bgr)
        print("⏸️ Added 30 extra frames to pause at end.")

video_writer.release()
print(f"🎬 Video saved as {OUTPUT_VIDEO_NAME}")
